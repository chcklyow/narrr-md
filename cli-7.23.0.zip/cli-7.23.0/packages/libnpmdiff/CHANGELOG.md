# Changelog

## 2.0.3

- fix name of options sent by the npm cli

## 2.0.2

- fix matching basename file filter

## 2.0.1

- fix for tarballs not listing folder names

## 2.0.0

- API rewrite:
  - normalized all options
  - specs to compare are now an array
- fix context=0
- added support to filtering by folder names

## 1.0.1

- fixed nameOnly option

## 1.0.0

- Initial release

